<?php $zunday_theme_options = get_option('zunday'); ?>         
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>