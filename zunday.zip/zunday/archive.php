<?php $zunday_theme_options = get_option('zunday'); ?>
<?php get_header(); ?>
<?php require get_parent_theme_file_path('/includes/gn-loop.php'); ?>  
<?php get_footer(); ?>