<?php if($zunday_theme_options['blog_styles_select'] == 1 || $zunday_theme_options['blog_styles_select'] == 2 || $zunday_theme_options['blog_styles_select'] == ""){ ?>
<div class="container">
   <div class="row">
      <div class="<?php if($zunday_theme_options['sidebar_position_select'] == 3 || $zunday_theme_options['sidebar_position_select'] == ""){ echo "col-12"; } ?> <?php if($zunday_theme_options['sidebar_position_select'] == 1){ echo "col-md-8"; } ?><?php if($zunday_theme_options['sidebar_position_select'] == 2){ echo "col-md-8 order-2"; } ?>">
         <?php global $more; $more = -1; ?>
         <?php if(have_posts()) : while(have_posts()) : the_post(); ?>
         <section data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="700" <?php post_class("aos-item"); ?>>
            <div class="blogitem text-center <?php if($zunday_theme_options['blog_styles_select'] == 2){ ?>full-img mobile-img-s <?php } ?> ">
               <a href="<?php the_permalink(); ?>">
                  <h2 class="blogitem-title blogitem-title-separator"><?php the_title(); ?></h2>
               </a>
               <div class="line-general"></div>
               <div class="blogitem-description">
                  <div>
                     <p><?php $content = get_the_excerpt(); echo substr($content, 0, 400); ?></p>
                  </div>
                  <p><a href="<?php the_permalink(); ?>" class="more-link"><span><?php echo esc_html__( 'Read More', 'zunday' ); ?></span></a></p>
               </div>
               <div class="iteminfo">
                  <div class="iteminfo-cont time">
                     <i class="fa fa-clock"></i><?php the_time('F j, Y'); ?>
                  </div>
                  <div class="iteminfo-cont comments">
                     <i class="fa fa-comments"></i> <?php comments_number( 'No comments', 'One comment', '% comments' ); ?>
                  </div>
                  <div class="clearfix"></div>
               </div>
               <?php if($zunday_theme_options['blog_styles_select'] == 2){ ?>
               <div class="bg-overlay"></div>
               <?php if(has_post_thumbnail() && '' != get_the_post_thumbnail()) :
                  $post_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large'); 
                  
                   ?>
               <div class="bg-image" style="background-image: url('<?php echo esc_url($post_image_url[0]); ?>')"></div>
               <?php endif; ?>  
               <?php } ?>   
            </div>
         </section>
         <?php endwhile;?>
         <div class="paginationCnt">
            <div class="pagination">
               <?php
                  global $wp_query;
                  
                  $big = 999999999; // need an unlikely integer
                  
                  echo paginate_links( array(
                    'base' => str_replace('#038;', '&', str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ) ),
                    'format' => '?paged=%#%',
                    'current' => max( 1, get_query_var('paged') ),
                    'total' => $wp_query->max_num_pages
                  ) );
                  ?>
               <div class="clearfix"></div>
            </div>
            <!-- /pagination -->
         </div>
         <?php else: ?> 
         <div class="noPosts"><span><?php echo esc_html__( 'No results match your search criteria...', 'zunday' ); ?></span></div>
         <?php endif; ?> 
      </div>
      <?php if($zunday_theme_options['sidebar_position_select'] != 3 && $zunday_theme_options['sidebar_position_select'] != ""): ?>
      <div class="col-md-4 <?php if($zunday_theme_options['sidebar_position_select'] == 1){ echo "order-2"; } ?><?php if($zunday_theme_options['sidebar_position_select'] == 2){ echo "order-1"; } ?>">
         <div class="widget-container sidebar sidebar_Side aos-item" data-aos="fade-up" data-aos-duration="700">
            <div class="row">
               <?php dynamic_sidebar('zunday_sidebar'); ?>
            </div>
         </div>
      </div>
      <?php endif; ?>              
   </div>
</div>
<!-- /container -->
<?php } //full width ?> 
<?php if($zunday_theme_options['blog_styles_select'] == 3 || $zunday_theme_options['blog_styles_select'] == 4){ ?>
<section class="grid">
   <?php global $more; $more = -1; ?>
   <?php if(have_posts()) : while(have_posts()) : the_post(); ?>    
   <?php 
      if($zunday_theme_options['blog_styles_select'] == 3){
         $pstClass = "grid__item aos-item grid-img_s"; 
      }else{
         $pstClass = "grid__item aos-item"; 
      }
      
      ?>
   <div data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="700" <?php post_class($pstClass); ?>>
      <a class="<?php if($zunday_theme_options['blog_styles_select'] == 3){ ?>full-img grid-img mobile-img-s<?php } ?>" href="<?php the_permalink(); ?>">
         <h2 class="title title--preview"><?php the_title(); ?></h2>
         <div class="line-general"></div>
         <span class="category"><?php $category = get_the_category(); echo esc_html($category[0]->cat_name); ?></span>
         <div class="meta meta--preview">
            <span class="meta__date"><i class="fa fa-clock"></i> <?php the_time('F j, Y'); ?></span>
            <span class="meta__reading-time"><i class="fa fa-comments"></i> <?php comments_number( 'No comments', 'One comment', '% comments' ); ?></span>
         </div>
         <?php if($zunday_theme_options['blog_styles_select'] == 3){ ?>
         <div class="bg-overlay"></div>
         <?php if(has_post_thumbnail() && '' != get_the_post_thumbnail()) :
            $post_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large'); 
            
             ?>
         <div class="bg-image" style="background-image: url('<?php echo esc_url($post_image_url[0]); ?>');"></div>
         <?php endif; ?>  
         <?php } ?> 
      </a>
   </div>
   <?php endwhile;?>
   <div class="paginationCnt">
      <div class="pagination">
         <?php
            global $wp_query;
            
            $big = 999999999; // need an unlikely integer
            
            echo paginate_links( array(
              'base' => str_replace('#038;', '&', str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ) ),
              'format' => '?paged=%#%',
              'current' => max( 1, get_query_var('paged') ),
              'total' => $wp_query->max_num_pages
            ) );
            ?>
         <div class="clearfix"></div>
      </div>
      <!-- /pagination -->
   </div>
   <?php else: ?> 
   <div class="noPosts"><span><?php echo esc_html__( 'No results match your search criteria...', 'zunday' ); ?></span></div>
   <?php endif; 
      ?>   
</section>
<?php } //grid ?>