<?php if(is_archive() || is_search()){ ?>
<div class="grid-top">
   <div class="row aos-item" data-aos="fade-up" data-aos-duration="700">
      <div class="col-md-12">
         <h3 class="title titleArchive">
            <?php 
               if(is_category()): 
                 printf( __( '<span class="title-section"><span>'.esc_html__( 'Category:', 'zunday' ).'</span> %s</span>', 'zunday' ), single_cat_title( '', false ));
               
               elseif(is_tag()): 
               printf( __( '<span class="title-section"><span>'.esc_html__( 'Tag:', 'zunday' ).'</span> %s</span>', 'zunday' ), single_tag_title( '', false ));
               
               elseif(is_search()): 
               printf( __( '<span class="title-section"><span>'.esc_html__( 'Search Results For:', 'zunday' ).'</span> %s</span>', 'zunday' ), esc_html( get_search_query( false ) ));
               
               elseif(is_author()): 
               printf( __( '<span class="title-section"><span>'.esc_html__( 'Author:', 'zunday' ).'</span> %s</span>', 'zunday' ), get_the_author( '', false ));
               
               else: 
                 $title = wp_title('', false);
                 printf( __( '<span class="title-section"><span>'.esc_html__( 'Archive:', 'zunday' ).'</span> %s</span>', 'zunday' ), $title);
               endif;                                                      
               
               ?>
         </h3>
      </div>
   </div>
</div>
<?php } ?>