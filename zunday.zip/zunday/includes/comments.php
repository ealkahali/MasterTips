<?php 
   if ( ! function_exists( 'zunday_comment_list' ) ) :
   
   function zunday_comment_list( $comment, $args, $depth ) {
   	$GLOBALS['comment'] = $comment;
   	switch ( $comment->comment_type ) :
   		case '' :
   	?>
<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
   <div id="comment-<?php comment_ID(); ?>" class="comment-wrap">
      <div class="comment-author vcard">
         <?php echo get_avatar( $comment, 300 ); ?>		
      </div>
      <div class="comment-body">
         <div class="comment-meta commentmetadata">
            <?php printf( sprintf( '<h3 class="fn">%s', get_comment_author_link() ) ); ?> <span class="comment-date-time">(<?php printf( __( '%1$s', 'zunday' ), get_comment_date() ); ?>)</span> 
            <b class="cm-btn edit-btn"><?php edit_comment_link( __( ' Edit', 'zunday' ), ' ' );?></b>
            <b class="cm-btn reply-comment"><?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?></b>
            </h3>
         </div>
         <?php if ( $comment->comment_approved == '0' ) : ?>
         <span class="comment-awaiting-moderation"><em><?php esc_html__( 'Your comment is awaiting moderation.', 'zunday' ); ?></em></span>
         <?php endif; ?>
         <?php comment_text(); ?>
      </div>
   </div>
   <?php
      break;
      case 'pingback'  :
      case 'trackback' :
      ?>
		<li class="post pingback">
		   <p><?php esc_html__( 'Pingback:', 'zunday' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( __( 'Edit', 'zunday' ), ' ' ); ?></p>
   <?php
      break;
      endswitch;
      }
      endif;
      ?>