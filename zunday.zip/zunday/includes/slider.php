<?php $zunday_theme_options = get_option('zunday'); ?>
<div class="grid-top<?php $zunday_theme_options['slider_category']; ?>">
   <div class="row">
      <div class="col-md-6 aos-item" data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="700">
         <div id="slider">
            <?php 
               if(isset($zunday_theme_options['slider_category']) && $zunday_theme_options['slider_category'] != ""): 
               
               $slider_category = $zunday_theme_options['slider_category'];
               
               $SliderItemCount = $zunday_theme_options['slider_item_count'];
               
               $argsBigSlider = array( 'posts_per_page' => $SliderItemCount, 'offset'=> 0, 'category' => $slider_category );
               $mypostsBigSlider = get_posts( $argsBigSlider );
               foreach ( $mypostsBigSlider as $post ) : setup_postdata( $post );  
               ?>
            <figure <?php post_class("effect-grid effect-grid-geight-full"); ?> >
               <?php
                  if(has_post_thumbnail() && '' != get_the_post_thumbnail()) :
                  
                  $post_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large'); 
                  
                  ?>
               <div class="bg-imagecont"  style="background-image: url(<?php echo esc_url($post_image_url[0]); ?>);"></div>
               <?php endif; ?>
               <figcaption>
                  <h2><?php the_title(); ?></h2>
                  <p><?php $content = get_the_excerpt(); echo substr($content, 0, 220); ?>...</p>
                  <p><a class="viewPost" href="<?php the_permalink(); ?>"><?php echo esc_html__( 'View Post', 'zunday' ); ?></a></p>
                  <a href="<?php the_permalink(); ?>"><?php echo esc_html__( 'Read More', 'zunday' ); ?></a>
               </figcaption>
            </figure>
            <?php 
               endforeach; 
               wp_reset_postdata(); 
               
               endif;
               ?>  
         </div>
      </div>
      <div class="col-md-6">
         <?php 
            if(isset($zunday_theme_options['slider_right_top']) && $zunday_theme_options['slider_right_top'] != ""): 
            
            $slider_right_top = $zunday_theme_options['slider_right_top'];
            $argsSliderTop = array( 'posts_per_page' => 1, 'offset'=> 0, 'category' => $slider_right_top );
            $mypostsSliderTop = get_posts( $argsSliderTop );
            foreach ( $mypostsSliderTop as $post ) : setup_postdata( $post ); 
            ?>
         <figure <?php post_class("effect-grid aos-item"); ?> data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="700" >
            <?php
               if(has_post_thumbnail() && '' != get_the_post_thumbnail()) :
               
               $post_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large'); 
               
               ?>
            <div class="bg-imagecont"  style="background-image: url(<?php echo esc_url($post_image_url[0]); ?>);"></div>
            <?php endif; ?>
            <figcaption>
               <h2><?php the_title(); ?></h2>
               <p><?php $content = get_the_excerpt();echo substr($content, 0, 100); ?>...</p>
               <a href="<?php the_permalink(); ?>"><?php echo esc_html__( 'View more', 'zunday' ); ?></a>
            </figcaption>
         </figure>
         <?php 
            endforeach; 
            wp_reset_postdata(); 
            
            endif; 
            ?>  
         <?php 
            if(isset($zunday_theme_options['slider_right_bottom']) && $zunday_theme_options['slider_right_bottom'] != ""):
            
            $slider_right_bottom = $zunday_theme_options['slider_right_bottom'];
            $argsSliderBottom = array( 'posts_per_page' => 1, 'offset'=> 0, 'category' => $slider_right_bottom );
            $mypostsSliderBottom = get_posts( $argsSliderBottom );
            foreach ( $mypostsSliderBottom as $post ) : setup_postdata( $post ); 
            ?>
         <figure <?php post_class("effect-grid aos-item"); ?> data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="700" >
            <?php
               if(has_post_thumbnail() && '' != get_the_post_thumbnail()) :
               
               $post_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large'); 
               
               ?>
            <div class="bg-imagecont"  style="background-image: url(<?php echo esc_url($post_image_url[0]); ?>);"></div>
            <?php endif; ?>
            <figcaption>
               <h2><?php the_title(); ?></h2>
               <p><?php $content = get_the_excerpt(); echo substr($content, 0, 100); ?>...</p>
               <a href="<?php the_permalink(); ?>"><?php echo esc_html__( 'View more', 'zunday' ); ?></a>
            </figcaption>
         </figure>
         <?php 
            endforeach; 
            wp_reset_postdata(); 
            
            endif;
            ?>  
      </div>
   </div>
</div>