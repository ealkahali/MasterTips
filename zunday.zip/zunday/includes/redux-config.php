<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux_Framework_sample_config' ) ) {

        class Redux_Framework_sample_config {

            public $args = array();
            public $sections = array();
            public $theme;
            public $ReduxFramework;

            public function __construct() {

                if ( ! class_exists( 'ReduxFramework' ) ) {
                    return;
                }

                // This is needed. Bah WordPress bugs.  ;)
                if ( true == Redux_Helpers::isTheme( __FILE__ ) ) {
                    $this->initSettings();
                } else {
                    add_action( 'plugins_loaded', array( $this, 'initSettings' ), 10 );
                }

            }

            public function initSettings() {

                // Just for demo purposes. Not needed per say.
                $this->theme = wp_get_theme();

                // Set the default arguments
                $this->setArguments();

                // Set a few help tabs so you can see how it's done
                $this->setHelpTabs();

                // Create the sections and fields
                $this->setSections();

                if ( ! isset( $this->args['opt_name'] ) ) { // No errors please
                    return;
                }

                // If Redux is running as a plugin, this will remove the demo notice and links
                //add_action( 'redux/loaded', array( $this, 'remove_demo' ) );

                // Function to test the compiler hook and demo CSS output.
                // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
                //add_filter('redux/options/'.$this->args['opt_name'].'/compiler', array( $this, 'compiler_action' ), 10, 3);

                // Change the arguments after they've been declared, but before the panel is created
                //add_filter('redux/options/'.$this->args['opt_name'].'/args', array( $this, 'change_arguments' ) );

                // Change the default value of a field after it's been set, but before it's been useds
                //add_filter('redux/options/'.$this->args['opt_name'].'/defaults', array( $this,'change_defaults' ) );

                // Dynamically add a section. Can be also used to modify sections/fields
                //add_filter('redux/options/' . $this->args['opt_name'] . '/sections', array($this, 'dynamic_section'));

                $this->ReduxFramework = new ReduxFramework( $this->sections, $this->args );
            }

            /**
             * This is a test function that will let you see when the compiler hook occurs.
             * It only runs if a field    set with compiler=>true is changed.
             * */
            function compiler_action( $options, $css, $changed_values ) {
                
                print_r( $changed_values ); // Values that have changed since the last save
                
                //print_r($options); //Option values
                //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )

                /*
              // Demo of how to use the dynamic CSS and write your own static CSS file
              $filename = dirname(__FILE__) . '/style' . '.css';
              global $wp_filesystem;
              if( empty( $wp_filesystem ) ) {
                require_once( ABSPATH .'/wp-admin/includes/file.php' );
              WP_Filesystem();
              }

              if( $wp_filesystem ) {
                $wp_filesystem->put_contents(
                    $filename,
                    $css,
                    FS_CHMOD_FILE // predefined mode settings for WP files
                );
              }
             */
            }

            /**
             * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
             * Simply include this function in the child themes functions.php file.
             * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
             * so you must use get_template_directory_uri() if you want to use any of the built in icons
             * */
            function dynamic_section( $sections ) {
                $sections[] = array(
                    'title'  => __( 'Section via hook', 'zunday' ),
                    'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'zunday' ),
                    'icon'   => 'el-icon-paper-clip',
                    // Leave this as a blank section, no options just some intro text set above.
                    'fields' => array()
                );

                return $sections;
            }

            /**
             * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
             * */
            function change_arguments( $args ) {

                return $args;
            }

            /**
             * Filter hook for filtering the default value of any given field. Very useful in development mode.
             * */
            function change_defaults( $defaults ) {
                $defaults['str_replace'] = 'Testing filter hook!';

                return $defaults;
            }


            public function setSections() {

                /**
                 * Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
                 * */
                // Background Patterns Reader
                $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
                $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
                $sample_patterns      = array();

                if ( is_dir( $sample_patterns_path ) ) :

                    if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) :
                        $sample_patterns = array();

                        while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {

                            if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
                                $name              = explode( '.', $sample_patterns_file );
                                $name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
                                $sample_patterns[] = array(
                                    'alt' => $name,
                                    'img' => $sample_patterns_url . $sample_patterns_file
                                );
                            }
                        }
                    endif;
                endif;

                ob_start();

                $ct          = wp_get_theme();
                $this->theme = $ct;
                $item_name   = $this->theme->get( 'Name' );
                $tags        = $this->theme->Tags;
                $screenshot  = $this->theme->get_screenshot();
                $class       = $screenshot ? 'has-screenshot' : '';

                $customize_title = sprintf( __( 'Customize &#8220;%s&#8221;', 'zunday' ), $this->theme->display( 'Name' ) );

                ?>
                <div id="current-theme" class="<?php echo esc_attr( $class ); ?>">
                    <?php if ( $screenshot ) : ?>
                        <?php if ( current_user_can( 'edit_theme_options' ) ) : ?>
                            <a href="<?php echo esc_url(wp_customize_url()); ?>" class="load-customize hide-if-no-customize"
                               title="<?php echo esc_attr( $customize_title ); ?>">
                                <img src="<?php echo esc_url( $screenshot ); ?>"
                                     alt="<?php esc_attr_e( 'Current theme preview', 'zunday' ); ?>"/>
                            </a>
                        <?php endif; ?>
                        <img class="hide-if-customize" src="<?php echo esc_url( $screenshot ); ?>"
                             alt="<?php esc_attr_e( 'Current theme preview', 'zunday' ); ?>"/>
                    <?php endif; ?>

                    

                    <div>
                        <ul class="theme-info">
                            <li><?php printf( __( 'By %s', 'zunday' ), $this->theme->display( 'Author' ) ); ?></li>
                            <li><?php printf( __( 'Version %s', 'zunday' ), $this->theme->display( 'Version' ) ); ?></li>
                      
                        </ul>
                        <p class="theme-description"><?php echo esc_html($this->theme->display( 'Description' )); ?></p>
            

                    </div>
                </div>

                <?php
                $item_info = ob_get_contents();

                ob_end_clean();

                $sampleHTML = '';
                if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
                    Redux_Functions::initWpFilesystem();

                    global $wp_filesystem;

                    $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
                }





            // General Settings
            $this->sections[] = array(
                'title'     => esc_html__( 'General Settings', 'zunday'),
                'icon'      => 'el-icon-adjust-alt',
                // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
                'fields'    => array(

                    array(
                        'id'        => 'general_site_style',
                        'type'      => 'select',
                        'title'     => esc_html__( 'General Site Style', 'zunday' ),
                        'options'  => array(
                            '1' => esc_html__( 'Light Style', 'zunday' ),
                            '2' => esc_html__( 'Dark Style', 'zunday' ),
                        ),
                        'default'  => '1'                        
                    ),   

                    array(
                        'id'=>'logo',
                        'type' => 'media', 
                        'title' => esc_html__( 'Logo (Light)', 'zunday' ),
                        'compiler' => 'true',
                        'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                    ),
                    array(
                        'id'=>'logo_light',
                        'type' => 'media', 
                        'title' => esc_html__( 'Logo (Dark)', 'zunday' ),
                        'compiler' => 'true',
                        'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                    ),                    
                    array(
                        'id'=>'logo_max_width',
                        'type' => 'text', 
                        'title' => esc_html__( 'Logo Max. Width', 'zunday' ),
                        'default' => '280px'
                    ),                        

                    array(
                        'id'=>'logo_subtitles',
                        'type' => 'text', 
                        'title' => esc_html__( 'Logo subtitle', 'zunday' ),
                        'default' => '#lifestyle #fashion #travel'
                    ), 

                    array(
                        'id'        => 'general-color',
                        'type'      => 'color',
                        'title'     => esc_html__( 'General site color', 'zunday' ),
                        'default'   => '#ff6d7e',
                        'validate'  => 'color',
                    ),                                                                                        
                                                                                                  
                    array(
                        'id'=>'favicon',
                        'type' => 'media', 
                        'title' => esc_html__( 'Favicon', 'zunday' ),
                        'compiler' => 'true',
                        'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        //'desc' => __('Favicon yükleyiniz', 'zunday')
                    ),         

                    array(
                        'id'=>'generalBgImg',
                        'type' => 'media', 
                        'title' => esc_html__( 'General Background Image', 'zunday' ),
                        'compiler' => 'true',
                        'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                    ),


                    array(
                        'id'=>'generalBgImg_opacity',
                        'type' => 'text', 
                        'title' => esc_html__( 'General Background Image - Opacity', 'zunday' ),
                        'default' => '0.08'
                    ),        


                    array(
                        'id'        => 'loading_display',
                        'type'      => 'switch',
                        'title'     => esc_html__( 'Loading', 'zunday' ),
                        'default'   => 1,
                        'on'        => 'Enabled',
                        'off'       => 'Disabled',
                    ), 


                                              
    
                                         
                ),
            );
 
            
            // Slider Options
            $this->sections[] = array(
                'icon'      => 'el-icon-magic',
                'title'     => esc_html__( 'Slider Options', 'zunday'),
                'fields'    => array(                                       
                    array(
                        'id'        => 'opt-notice-critical',
                        'type'      => 'info',
                        'notice'    => true,
                        'style'     => 'critical',
                        'icon'      => 'el-icon-info-sign',
                        'title'     => esc_html__( 'Important', 'zunday' ),
                        'desc'      => esc_html__( 'If the category is empty, the categories don\'t show.', 'zunday')
                    ),

                    array(
                        'id'        => 'slider_display',
                        'type'      => 'switch',
                        'title'     => esc_html__( 'Enabled / Disabled?', 'zunday' ),
                        'default'   => 1,
                        'on'        => 'Enabled',
                        'off'       => 'Disabled',
                    ),     

                    array(
                        'id'        => 'slider_category',
                        'type'      => 'select',
                        'data'      => 'categories',
                        'title'     => esc_html__( 'Slider Category', 'zunday' ),
                        'subtitle'  => esc_html__( 'Choose the slider category.', 'zunday' ),
                        'desc'      => esc_html__( 'If the category is empty, the category don\'t show.', 'zunday' ),
                        'default' => '0'
                    ),      

                    array(
                        'id'=>'slider_item_count',
                        'type' => 'text', 
                        'title' => esc_html__( 'Slider Item Count', 'zunday' ),
                        'default' => '4'
                    ),  


                    array(
                        'id'        => 'slider_right_top',
                        'type'      => 'select',
                        'data'      => 'categories',
                        'title'     => esc_html__( 'Right side of slider - Top', 'zunday' ),
                        'subtitle'  => esc_html__( 'Choose the category.', 'zunday' ),
                        'desc'      => esc_html__( 'If the category is empty, the category don\'t show.', 'zunday' ),
                        'default' => '0'
                    ),         

                    array(
                        'id'        => 'slider_right_bottom',
                        'type'      => 'select',
                        'data'      => 'categories',
                        'title'     => esc_html__( 'Right side of slider - Bottom', 'zunday' ),
                        'subtitle'  => esc_html__( 'Choose the category.', 'zunday' ),
                        'desc'      => esc_html__( 'If the category is empty, the category don\'t show.', 'zunday' ),
                        'default' => '0'
                    ),                                          

                )
            );



            
             $this->sections[] = Array(
                'title' => esc_html__( 'Typography', 'zunday' ),
                'icon'  => 'el-icon-font',
                'fields'=> Array(
               

                    array(
                        'id'        => 'zunday_nav_font',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Navigation Main Title', 'zunday' ),
                        'subtitle'  => esc_html__( 'Specify the navigation font properties.', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>true,
                        'color'=>false,
                        'subsets'       => false,
                        'output'        => array('.menu--zunday .menu__item-name, .menu--zunday ul li a'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Playfair Display',
                            'font-size'     => '19px',
                            //'text-transform'   => 'uppercase',
                            'font-weight'   => '700'
                        ),               
                    ),



                    array(
                        'id'        => 'zunday_nav_font_sub',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Navigation Sub Title', 'zunday' ),
                        'subtitle'  => esc_html__( 'Specify the navigation sub title font properties.', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>true,
                        'color'=>false,
                        'subsets'       => false,
                        'output'        => array('.menu--zunday .menu__item-label'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Playfair Display',
                            'font-size'     => '15px',
                            //'text-transform'   => 'uppercase',
                            'font-weight'   => '400'
                        ),               
                    ),                    



                    array(
                        'id'        => 'post_titles_full_width',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Post Title (Full Width Style)', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>false,
                        'color'=>false,
                        'font-size' => true,
                        'subsets'       => false,
                        'output'        => array('.blogitem-title'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Playfair Display',
                            'font-size'     => '40px',
                            'font-weight'   => '700',
                            'color' => '#1f1f1f',
                        ),               
                    ), 


                    array(
                        'id'        => 'post_titles_grid',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Post Title (Grid Style)', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>false,
                        'color'=>false,
                        'font-size' => true,
                        'subsets'       => false,
                        'output'        => array('.grid .title'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Playfair Display',
                            'font-size'     => '26px',
                            'font-weight'   => '700',
                            'line-height'   => '33px',
                            'color' => '#1f1f1f',
                        ),               
                    ),                      


                    array(
                        'id'        => 'slider_big_title',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Slider Big Box Title', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>false,
                        'color'=>false,
                        'font-size' => true,
                        'subsets'       => false,
                        'output'        => array('#slider figure.effect-grid-geight-full h2'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Playfair Display',
                            'font-weight'   => '700',
                            'font-size'     => '45px',
                            'line-height'     => '52px'
                        ),               
                    ),  


                    array(
                        'id'        => 'slider_big_desc',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Slider Big Box Description', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>false,
                        'color'=>false,
                        'font-size' => true,
                        'subsets'       => false,
                        'output'        => array('figure.effect-grid-geight-full p'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Open Sans',
                            'font-weight'   => '400',
                            'font-size'     => '16px',
                            'line-height'     => '28px',
                        ),               
                    ),


                    array(
                        'id'        => 'slider_big_button',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Slider Big Box Button ', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>false,
                        'color'=>false,
                        'font-size' => true,
                        'subsets'       => false,
                        'output'        => array('a.viewPost'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Playfair Display',
                            'font-weight'   => '700',
                            'font-size'     => '15px',
                            'line-height'     => '27px',
                        ),               
                    ),                          





                    array(
                        'id'        => 'right_side_slider_boxes',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Right side of slider - Title', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>false,
                        'color'=>false,
                        'font-size' => true,
                        'subsets'       => false,
                        'output'        => array('figure.effect-grid h2'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Playfair Display',
                            'font-weight'   => '700',
                            'font-size'     => '32px',
                            'line-height'     => '36px'
                        ),               
                    ),  



                    array(
                        'id'        => 'blockquote',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Blockquote', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>false,
                        'color'=>false,
                        'font-size' => true,
                        'subsets'       => false,
                        'output'        => array('blockquote, .blockquote, .content-detail blockquote p'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Playfair Display',
                            'font-weight'   => '200',
                            'line-height'     => '35px',
                            'font-size'     => '22px'
                        ),               
                    ),                      


          

         



                    array(
                        'id'        => 'other_content_fonts',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Other contents', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>false,
                        'color'=>false,
                        'font-size' => false,
                        'subsets'       => false,
                        'output'        => array('a,body,p'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Open Sans'
                        ),               
                    ),   



                    array(
                        'id'        => 'content_fonts_size',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Detail/content pages', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>false,
                        'color'=>false,
                        'font-size' => true,
                        'subsets'       => false,
                        'output'        => array('.DetailPages .content p'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Open Sans',
                            'font-size'     => '16px',
                            'color'         => '#404040',
                            'font-weight'   => 'normal'
                        ),               
                    ),                                                                                

          


                    array(
                        'id'        => 'widget_title_font',
                        'type'      => 'typography',
                        'title'     => esc_html__( 'Widgets title', 'zunday' ),
                        'google'    => true,
                        'text-align'=>true,
                        'font-family'=>true,
                        'font-style'=>true,
                        'line-height'=>true,
                        'text-transform'=>false,
                        'color'=>false,
                        'font-size' => true,
                        'subsets'       => false,
                        'output'        => array('.widget .widget-title'), 
                        'units'         => 'px', // Defaults to px
                        'default'   => array(
                            'font-family'   => 'Playfair Display',
                            'font-weight'   => '700',
                            'text-transform'=> 'uppercase',
                            'font-size'     => '19px',
                            'letter-spacing'     => '2px',
                            'color'     => '#797979',
                        ),               
                    ),    

                )
            );   



            // Post Options
            $this->sections[] = array(
                'icon'      => 'el-icon-pencil',
                'title'     => esc_html__( 'Post Options', 'zunday' ),
                'fields'    => array( 
                    array(
                        'id'        => 'cover_image_display',
                        'type'      => 'switch',
                        'title'     => esc_html__( 'Cover Image', 'zunday' ),
                        'default'   => 1,
                        'on'        => 'Enabled',
                        'off'       => 'Disabled',
                    ),                                                       
                    array(
                        'id'        => 'author_display',
                        'type'      => 'switch',
                        'title'     => esc_html__('Author Widget', 'zunday'),
                        'default'   => 1,
                        'on'        => 'Enabled',
                        'off'       => 'Disabled',
                    ),
                    array(
                        'id'        => 'tag_display',
                        'type'      => 'switch',
                        'title'     => esc_html__('Tags', 'zunday'),
                        'default'   => 1,
                        'on'        => 'Enabled',
                        'off'       => 'Disabled',
                    ),       
                    array(
                        'id'        => 'related_posts_display',
                        'type'      => 'switch',
                        'title'     => esc_html__('Related Posts', 'zunday'),
                        'default'   => 1,
                        'on'        => 'Enabled',
                        'off'       => 'Disabled',
                    ),                                                                                                                                                                                                                                                             
                )
            );





            // Sidebar Options
            $this->sections[] = array(
                'icon'      => 'el-icon-delicious',
                'title'     => esc_html__('Sidebar Options', 'zunday'),
                'fields'    => array(                                       
                    array(
                        'id'        => 'sidebar_position_select',
                        'type'      => 'select',
                        'title'     => esc_html__('Sidebars Position', 'zunday'),
                        'subtitle'  => esc_html__('Choose the sidebar position for all pages.', 'zunday'),
                        'options'  => array(
                            '1' => esc_html__('Right Sidebar (for full width)', 'zunday' ),
                            '2' => esc_html__('Left Sidebar (for full width)', 'zunday'),
                            '3' => esc_html__('Full Width (w/o sidebar) for all page', 'zunday')
                        ),
                        'default'  => '3'                        
                    ),                                                                                                                                                                                      
                )
            );



            // Blog Styles
            $this->sections[] = array(
                'icon'      => 'el-icon-list',
                'title'     => esc_html__('Blog Styles', 'zunday'),
                'fields'    => array(                                       
                    array(
                        'id'        => 'blog_styles_select',
                        'type'      => 'select',
                        'title'     => esc_html__('Blog Styles', 'zunday'),
                        'subtitle'  => esc_html__('Choose the blog style.', 'zunday'),
                        'options'  => array(
                            '1' => esc_html__('Full width (without photo)', 'zunday' ),
                            '2' => esc_html__('Full width (with photo)', 'zunday' ),
                            '3' => esc_html__('Grid - (with photo)', 'zunday' ),
                            '4' => esc_html__('Grid - (without photo)', 'zunday' )
                        ),
                        'default'  => '1'                        
                    ),                                                                                                                                                                                      
                )
            );            



            // Social Media Options
            $this->sections[] = array(
                'title'     => esc_html__('Social Media Options', 'zunday'),
                'icon'      => 'el-icon-group',
                // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
                'fields'    => array(       

                    array(
                        'id'        => 'socialmedia_display',
                        'type'      => 'switch',
                        'title'     => esc_html__( 'Social Media', 'zunday' ),
                        'default'   => 2,
                        'on'        => 'Enabled',
                        'off'       => 'Disabled',
                    ),     

                    array(
                    'id'=>'rss',
                    'type' => 'text', 
                    'title' => esc_html__('Rss', 'zunday'),
                    'default' => ''
                    ),
                    array(
                    'id'=>'Twitter',
                    'type' => 'text', 
                    'title' => esc_html__('Twitter', 'zunday'),
                    'default' => '#Twitter'
                    ), 
                    array(
                    'id'=>'Facebook',
                    'type' => 'text', 
                    'title' => esc_html__('Facebook', 'zunday'),
                    'default' => '#Facebook'
                    ),
                    array(
                    'id'=>'Google',
                    'type' => 'text', 
                    'title' => esc_html__('Google Plus', 'zunday'),
                    'default' => ''
                    ), 
                    array(
                    'id'=>'Pinterest',
                    'type' => 'text', 
                    'title' => esc_html__('Pinterest', 'zunday'),
                    'default' => ''
                    ),  
                    array(
                    'id'=>'tumblr',
                    'type' => 'text', 
                    'title' => esc_html__('Tumblr', 'zunday'),
                    'default' => ''
                    ),   
                    array(
                    'id'=>'Dribbble',
                    'type' => 'text', 
                    'title' => esc_html__('Dribbble', 'zunday'),
                    'default' => ''
                    ),    
                    array(
                    'id'=>'Linkedin',
                    'type' => 'text', 
                    'title' => esc_html__('Linkedin', 'zunday'),
                    'default' => '#linkedin'
                    ),   
                    array(
                    'id'=>'Github',
                    'type' => 'text', 
                    'title' => esc_html__('Github', 'zunday'),
                    'default' => ''
                    ),   
                    array(
                    'id'=>'Skype',
                    'type' => 'text', 
                    'title' => esc_html__('Skype', 'zunday'),
                    'default' => ''
                    ), 
                    array(
                    'id'=>'YouTube',
                    'type' => 'text', 
                    'title' => esc_html__('YouTube', 'zunday'),
                    'default' => ''
                    ),  
                    array(
                    'id'=>'Flickr',
                    'type' => 'text', 
                    'title' => esc_html__('Flickr', 'zunday'),
                    'default' => ''
                    ),                                                                                                                                                                                                                                                                     
                ),
            );






                $this->sections[] = array(
                    'title'  => esc_html__( 'Import / Export', 'zunday' ),
                    'desc'   => esc_html__( 'Import and Export your Redux Framework settings from file, text or URL.', 'zunday' ),
                    'icon'   => 'el-icon-refresh',
                    'fields' => array(
                        array(
                            'id'         => 'opt-import-export',
                            'type'       => 'import_export',
                            'title'      => 'Import Export',
                            'subtitle'   => esc_html__('Save and restore your Redux options', 'zunday'),
                            'full_width' => false,
                        ),
                    ),
                );

                $this->sections[] = array(
                    'type' => 'divide',
                );

                $this->sections[] = array(
                    'icon'   => 'el-icon-info-sign',
                    'title'  => esc_html__( 'Theme Information', 'zunday' ),
                    //'desc'   => esc_html__( '<p class="description">This is the Description. Again HTML is allowed</p>', 'zunday' ),
                    'fields' => array(
                        array(
                            'id'      => 'opt-raw-info',
                            'type'    => 'raw',
                            'content' => $item_info,
                        )
                    ),
                );

            }

            public function setHelpTabs() {

                // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
                $this->args['help_tabs'][] = array(
                    'id'      => 'redux-help-tab-1',
                    'title'   => __( 'Theme Information 1', 'zunday' ),
                    'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'zunday' )
                );

                $this->args['help_tabs'][] = array(
                    'id'      => 'redux-help-tab-2',
                    'title'   => __( 'Theme Information 2', 'zunday' ),
                    'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'zunday' )
                );

                // Set the help sidebar
                $this->args['help_sidebar'] = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'zunday' );
            }

            /**
             * All the possible arguments for Redux.
             * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
             * */
            public function setArguments() {

                $theme = wp_get_theme(); // For use with some settings. Not necessary.

                $this->args = array(
                    // TYPICAL -> Change these values as you need/desire
                    'opt_name'             => 'zunday',
                    // This is where your data is stored in the database and also becomes your global variable name.
                    'display_name'         => $theme->get( 'Name' ),
                    // Name that appears at the top of your panel
                    'display_version'      => $theme->get( 'Version' ),
                    // Version that appears at the top of your panel
                    'menu_type'            => 'menu',
                    //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                    'allow_sub_menu'       => true,
                    // Show the sections below the admin menu item or not
                    'menu_title'           => __( 'Zunday Options', 'zunday' ),
                    'page_title'           => __( 'Zunday Options', 'zunday' ),
                    // You will need to generate a Google API key to use this feature.
                    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
                    'google_api_key'       => '',
                    // Set it you want google fonts to update weekly. A google_api_key value is required.
                    'google_update_weekly' => false,
                    // Must be defined to add google fonts to the typography module
                    'async_typography'     => true,
                    // Use a asynchronous font on the front end or font string
                    //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
                    'admin_bar'            => true,
                    // Show the panel pages on the admin bar
                    'admin_bar_icon'     => 'dashicons-portfolio',
                    // Choose an icon for the admin bar menu
                    'admin_bar_priority' => 50,
                    // Choose an priority for the admin bar menu
                    'global_variable'      => '',
                    // Set a different name for your global variable other than the opt_name
                    'dev_mode'             => false,
                    // Show the time the page took to load, etc
                    'update_notice'        => false,
                    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
                    'customizer'           => true,
                    // Enable basic customizer support
                    //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
                    //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

                    // OPTIONAL -> Give you extra features
                    'page_priority'        => null,
                    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                    'page_parent'          => 'themes.php',
                    // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                    'page_permissions'     => 'manage_options',
                    // Permissions needed to access the options panel.
                    'menu_icon'            => '',
                    // Specify a custom URL to an icon
                    'last_tab'             => '',
                    // Force your panel to always open to a specific tab (by id)
                    'page_icon'            => 'icon-themes',
                    // Icon displayed in the admin panel next to your menu_title
                    'page_slug'            => '_options',
                    // Page slug used to denote the panel
                    'save_defaults'        => true,
                    // On load save the defaults to DB before user clicks save or not
                    'default_show'         => false,
                    // If true, shows the default value next to each field that is not the default value.
                    'default_mark'         => '',
                    // What to print by the field's title if the value shown is default. Suggested: *
                    'show_import_export'   => true,
                    // Shows the Import/Export panel when not used as a field.

                    // CAREFUL -> These options are for advanced use only
                    'transient_time'       => 60 * MINUTE_IN_SECONDS,
                    'output'               => true,
                    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                    'output_tag'           => true,
                    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                    // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

                    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                    'database'             => '',
                    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                    'system_info'          => false,
                    // REMOVE

                    // HINTS
                    'hints'                => array(
                        'icon'          => 'icon-question-sign',
                        'icon_position' => 'right',
                        'icon_color'    => 'lightgray',
                        'icon_size'     => 'normal',
                        'tip_style'     => array(
                            'color'   => 'light',
                            'shadow'  => true,
                            'rounded' => false,
                            'style'   => '',
                        ),
                        'tip_position'  => array(
                            'my' => 'top left',
                            'at' => 'bottom right',
                        ),
                        'tip_effect'    => array(
                            'show' => array(
                                'effect'   => 'slide',
                                'duration' => '500',
                                'event'    => 'mouseover',
                            ),
                            'hide' => array(
                                'effect'   => 'slide',
                                'duration' => '500',
                                'event'    => 'click mouseleave',
                            ),
                        ),
                    )
                );

                // ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
                $this->args['admin_bar_links'][] = array(
                    'id'    => 'redux-docs',
                    'href'   => 'http://docs.reduxframework.com/',
                    'title' => __( 'Documentation', 'zunday' ),
                );

                $this->args['admin_bar_links'][] = array(
                    //'id'    => 'redux-support',
                    'href'   => 'https://github.com/ReduxFramework/redux-framework/issues',
                    'title' => __( 'Support', 'zunday' ),
                );

                $this->args['admin_bar_links'][] = array(
                    'id'    => 'redux-extensions',
                    'href'   => 'reduxframework.com/extensions',
                    'title' => __( 'Extensions', 'zunday' ),
                );


                // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
                /*
                $this->args['share_icons'][] = array(
                    'url'   => 'https://www.facebook.com/pages/The-Wordpress-Themes/735055726525354',
                    'title' => 'Like us on Facebook',
                    'icon'  => 'el-icon-facebook'
                );
                $this->args['share_icons'][] = array(
                    'url'   => 'https://twitter.com/thewpthemescom',
                    'title' => 'Follow us on Twitter',
                    'icon'  => 'el-icon-twitter'
                );*/

                // Panel Intro text -> before the form
                /*
                if ( ! isset( $this->args['global_variable'] ) || $this->args['global_variable'] !== false ) {
                    if ( ! empty( $this->args['global_variable'] ) ) {
                        $v = $this->args['global_variable'];
                    } else {
                        $v = str_replace( '-', '_', $this->args['opt_name'] );
                    }
                    $this->args['intro_text'] = sprintf( __( '<p>Did you know that Redux sets a global variable for you? To access any of your saved options from within your code you can use your global variable: <strong>$%1$s</strong></p>', 'zunday' ), $v );
                } else {
                    $this->args['intro_text'] = __( '<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'zunday' );
                }*/

                // Add content after the form.
                /*
                $this->args['footer_text'] = __( '<p>This text is displayed below the options panel. It isn\'t required, but more info is always better! The footer_text field accepts all HTML.</p>', 'zunday' );*/
            }

            public function validate_callback_function( $field, $value, $existing_value ) {
                $error = true;
                $value = 'just testing';

                /*
              do your validation

              if(something) {
                $value = $value;
              } elseif(something else) {
                $error = true;
                $value = $existing_value;
                
              }
             */

                $return['value'] = $value;
                $field['msg']    = 'your custom error message';
                if ( $error == true ) {
                    $return['error'] = $field;
                }

                return $return;
            }

            public function class_field_callback( $field, $value ) {
                print_r( $field );
                print_r( $value );
            }

        }

        global $reduxConfig;
        $reduxConfig = new Redux_Framework_sample_config();
    } else {
        
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ):
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            
            print_r( $value );
        }
    endif;

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ):
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error = true;
            $value = 'just testing';

            /*
          do your validation

          if(something) {
            $value = $value;
          } elseif(something else) {
            $error = true;
            $value = $existing_value;
            
          }
         */

            $return['value'] = $value;
            $field['msg']    = 'your custom error message';
            if ( $error == true ) {
                $return['error'] = $field;
            }

            return $return;
        }
    endif;
